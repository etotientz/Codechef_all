Tic-Tac-Toe
=============

If you want to see debug messages add,

      #define DEBUG

to the start of both client.c and server.c before compiling. 

To compile, cd to this directory and run: 

      make all

To run the server: 
      
      ./server [some port]

To run the clients: 

      ./client [server host] [some port]
